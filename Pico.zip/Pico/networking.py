import network
from utils import wait_with_wdt, feed_wdt
from machine import reset, Pin
import socket
import time

BACKOFF_DELAYS = [
    (5, 3),
    (10, 3),
    (30, 3),
    (60, 5),
    (300, 100), 
]

def is_connected():
    return network.WLAN(network.STA_IF).status() == 3

def status():
    return network.WLAN(network.STA_IF).status()

def wifi_status_string(status_code):
    status_strings = {
        0: "Not enabled",
        1: "Currently scanning for networks",
        2: "Connecting to a network",
        3: "Connected to a network",
        4: "Failed to connect to a network"
    }
    return status_strings.get(status_code, "Unknown") 

def ensure_wifi(ssid, password):
    if is_connected():
        return True

    print("WiFi not connected. Reconnecting...")
    return reconnect_wifi(ssid, password)


def initialize_wifi(ssid, password, timeout=30):

    # # Pin 23 is the hardware power-on pin for the Wi-Fi chip
    # wl_on = Pin(23, Pin.OUT)

    # # Force-drain the Wi-Fi chip's power
    # wl_on.low()
    # time.sleep_ms(1000) # Must wait for internal capacitors to fully empty

    # # Restore power and give the chip a moment to stabilize
    # wl_on.high()
    # time.sleep_ms(1000) # Must wait for internal capacitors to fully charge

    print(f"Initializing Wi-Fi connection to SSID: {ssid}")
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wait_with_wdt(2)  # Wait for the interface to become active
    # Connect to the network
    wlan.connect(ssid, password)

    # Wait for Wi-Fi connection

    while timeout > 0:
        wait_with_wdt(2)
        wifi_status = wlan.status()
        if wifi_status >= 3:
            break
        timeout -= 2
        print(f'Waiting for Wi-Fi connection... {wifi_status_string(wifi_status)}')
        

    # Check if connection is successful
    if wifi_status != 3:
        print(f'Failed to connect: {wifi_status_string(wifi_status)}')
        return False
    else:
        network_info = wlan.ifconfig()
        print('Connection successful!')
        print("IFCONFIG:", network_info)
        print("RSSI:", wlan.status('rssi'))
        wait_with_wdt(2)
        return test_wifi_connection()


def test_wifi_connection():
    try:
        # addr = socket.getaddrinfo("www.google.com", 80)[0][-1]
        # print(f"Tested DNS: {addr}")
        # s = socket.socket()
        # s.settimeout(10)
        # s.connect(addr)
        # print("TCP connect worked")
        # s.close()
        return True

    except Exception as e:
        print("TCP test failed:", e)
        return False
    

def reconnect_wifi(ssid, password):
    for delay, attempts in BACKOFF_DELAYS:
        for _ in range(attempts):
            if initialize_wifi(ssid, password, timeout=30):
                return True

            print(f"Waiting {delay} seconds before next attempt...")
            wait_with_wdt(delay)

    print("Too many failures, rebooting")
    reset()