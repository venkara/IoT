# Configuration file for the IoT sensor project

# WiFi credentials
wifi_ssid = 'Vast Underground Network'
wifi_password = 'dessert-oozy-dumpling-sucre-4'

# MQTT broker settings
mqtt_server = b'io.adafruit.com'
mqtt_username = b'rvenkat'
mqtt_password = b'aio_ICaz87GljVJJ1wjzphIgkFXSiv9T'
mqtt_topic_root = 'rvenkat/feeds/tres-lunas.'

# Hardware configuration
dht22_pin = 16  # GPIO pin for DHT22 sensor

# Publish interval in seconds (5 minutes)
mqtt_publish_interval = 5 * 60  # seconds

# Last three bytes of the MAC address mapped to sensor numbers
SENSOR_NUMBERS = {
    "131A17": 1,
    "131A19": 2,
    "131A1B": 3
}
# Set to False to disable the watchdog timer for debugging
ENABLE_WDT = True

