wifi_ssid = 'Vast Underground Network'
wifi_password = 'dessert-oozy-dumpling-sucre-4'
mqtt_server = b'io.adafruit.com'
#mqtt_ip_address = b'52.7.84.197'
mqtt_username = b'rvenkat'
mqtt_password = b'aio_ZZbn27d2YUk1SoDsPAC5l6MoLiYX'
mqtt_root = b'rvenkat/feeds/tres-lunas.'
data_interval_sec = 1 * 60  # seconds


SENSOR_NUMBERS = {
    "131A17": 1,
    "131A19": 2,
    "131A1B": 3
}

