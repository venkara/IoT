wifi_ssid = 'Vast Underground Network'
wifi_password = 'dessert-oozy-dumpling-sucre-4'
mqtt_server = b'io.adafruit.com'
#mqtt_ip_address = b'52.7.84.197'
mqtt_username = b'rvenkat'
mqtt_password = b'aio_omsY85910BrZYgBsgw4MbF6jJeAb'
mqtt_root = b'rvenkat/feeds/tres-lunas.'
mqtt_publish_interval = 1 * 60  # seconds
dht22_pin = 16  # GPIO pin for DHT22 sensor
DEBUG_NO_WDT = True  # Set to True to disable the watchdog timer for debugging
fahrenheit = True  # Set to True to display temperature in Fahrenheit, False for Celsius


SENSOR_NUMBERS = {
    "131A17": 1,
    "131A19": 2,
    "131A1B": 3
}

SENSOR_TEMP_CAL = { # specified in degrees Celsius
    1: 0.0,
    2: 0.0,
    3: 0.0
}

SENSOR_RH_CAL = {
    1: -4.0,
    2: 0.0,
    3: 0.0
}
